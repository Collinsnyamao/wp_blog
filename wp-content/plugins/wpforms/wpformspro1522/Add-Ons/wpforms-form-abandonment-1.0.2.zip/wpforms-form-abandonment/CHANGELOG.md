# Change Log
All notable changes to this project will be documented in this file, formatted via [this recommendation](http://keepachangelog.com/).

## [1.0.2] - 2018-02-12
### Fixed
- Conflict with email notifications configured with conditional logic causing notifications to send when they should not.

## [1.0.1] - 2017-02-01
### Fixed
- Incorrect version in updater which caused WordPress to think an update was available.

## [1.0.0] - 2017-02-01
### Added
- Initial release.