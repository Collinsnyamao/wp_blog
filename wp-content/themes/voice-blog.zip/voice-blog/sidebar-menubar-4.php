<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package voice_blog
 */

?>
<aside id="sidebar-4" class="widget-area sidebar">
	<?php dynamic_sidebar( 'sidebar-4' ); ?>
</aside><!-- #secondary -->
