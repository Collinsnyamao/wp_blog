<?php 

get_template_part( 'inc/theme/footers/footer'); ?>

</div> <!-- / wrapper -->
<div class="site-navigation-overlay"></div>
<?php wp_footer(); ?>
</body>
</html>