<div class="entry-author">
<?php 
	global $post;
	writee_author_box($post->post_author);
?>
</div><!-- #author-box -->